﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tonzler_s_List
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public Form2(string source)
        {
            InitializeComponent();
            listBox1.Items.AddRange(source.Split(new string[] { "\n" }, StringSplitOptions.None));
        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
