﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Security;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using System.IO;

namespace Tonzler_s_List
{
    public partial class Form1 : Form
    {
        bool age_ValidInput = false;
        bool usrtelno1_ValidInput = false;
        bool usrtelno2_ValidInput = false;
        bool usrtelno3_ValidInput = false;
        WebClient wc;
        Dictionary<string, string> configs;
        string wcDownloadString;
        bool FLAG_procnext = true;

        Dictionary<int, Dictionary<string, string>> tzList; 

        public Form1()
        {
            InitializeComponent();
            wc = new WebClient();
            try
            {
                ServicePointManager.ServerCertificateValidationCallback =
                    new RemoteCertificateValidationCallback(
                        delegate
                        { return true; }
                    );
            }
            catch
            { }
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            maskedTextBox1.ValidatingType = typeof(int);
            maskedTextBox2.ValidatingType = typeof(int);
            maskedTextBox3.ValidatingType = typeof(int);
            maskedTextBox4.ValidatingType = typeof(int);
            personalinfo_load();

            tzList = new Dictionary<int, Dictionary<string, string>>();

            // 設定ファイル一覧の初期化
            configs = new Dictionary<string, string>();
            string dir = System.Windows.Forms.Application.StartupPath + @"\conf\";
            var files = System.IO.Directory.GetFiles(dir, "*.txt");
            foreach (string fp in files)
            {
                configs.Add(Path.GetFileNameWithoutExtension(fp), fp);
            }
            comboBox3.Items.AddRange(configs.Keys.ToArray());
        }

        private void maskedTextBox1_TypeValidationCompleted(object sender, TypeValidationEventArgs e)
        {
            age_ValidInput = e.IsValidInput;
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void maskedTextBox1_Enter(object sender, EventArgs e)
        {
            maskedTextBox1.Focus();
            maskedTextBox1.SelectAll();
        }

        private void maskedTextBox2_Enter(object sender, EventArgs e)
        {
            maskedTextBox2.Focus();
            maskedTextBox2.SelectAll();
        }

        private void maskedTextBox3_Enter(object sender, EventArgs e)
        {
            maskedTextBox3.Focus();
            maskedTextBox3.SelectAll();
        }

        private void maskedTextBox4_Enter(object sender, EventArgs e)
        {
            maskedTextBox4.Focus();
            maskedTextBox4.SelectAll();
        }

        private void maskedTextBox2_TypeValidationCompleted(object sender, TypeValidationEventArgs e)
        {
            usrtelno1_ValidInput = e.IsValidInput;
        }

        private void maskedTextBox3_TypeValidationCompleted(object sender, TypeValidationEventArgs e)
        {
            usrtelno2_ValidInput = e.IsValidInput;
        }

        private void maskedTextBox4_TypeValidationCompleted(object sender, TypeValidationEventArgs e)
        {
            usrtelno3_ValidInput = e.IsValidInput;
        }

        /// <summary>
        /// 個人情報のリセットボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            maskedTextBox1.Text = "";
            maskedTextBox2.Text = "";
            maskedTextBox3.Text = "";
            maskedTextBox4.Text = "";
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;

        }

        private void tableLayoutPanel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void 終了XToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        string T1_URI;
        string T1_Title;
        DataGridView dv;
        private System.Windows.Forms.DataGridViewTextBoxColumn LineNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataID;
        private System.Windows.Forms.DataGridViewComboBoxColumn DataType;
        private System.Windows.Forms.DataGridViewComboBoxColumn ProcType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProcData;
        private System.Windows.Forms.DataGridViewTextBoxColumn Comment;

        int wait_inputpage = 5;
        int wait_confirmpage = 10;
        int wait_finishpage = 5;
        int wait_errpage = 100;

        /// <summary>
        /// データの取得
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            stat_write("設定情報を読み込み中 ...");
            dv = new DataGridView();
            this.LineNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ProcType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ProcData = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Comment = new System.Windows.Forms.DataGridViewTextBoxColumn();

            dv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LineNumber,
            this.DataID,
            this.DataType,
            this.ProcType,
            this.ProcData,
            this.Comment});
            // 
            // LineNumber
            // 
            this.LineNumber.HeaderText = "行番号";
            this.LineNumber.MaxInputLength = 10;
            this.LineNumber.Name = "LineNumber";
            this.LineNumber.Width = 70;
            // 
            // DataID
            // 
            this.DataID.HeaderText = "データID";
            this.DataID.MaxInputLength = 10;
            this.DataID.Name = "DataID";
            this.DataID.Width = 70;
            // 
            // DataType
            // 
            this.DataType.HeaderText = "データタイプ";
            this.DataType.Items.AddRange(new object[] {
            "RegExp",
            "name1",
            "name2",
            "workname",
            "workaddr",
            "worktelno"});
            this.DataType.Name = "DataType";
            // 
            // ProcType
            // 
            this.ProcType.HeaderText = "処理方法";
            this.ProcType.Items.AddRange(new object[] {
            "RegExp",
            "Substr"});
            this.ProcType.Name = "ProcType";
            // 
            // ProcData
            // 
            this.ProcData.HeaderText = "処理内容";
            this.ProcData.Name = "ProcData";
            this.ProcData.Width = 800;
            // 
            // Comment
            // 
            this.Comment.HeaderText = "備考";
            this.Comment.Name = "Comment";
            this.Comment.Width = 300;


            string fn = configs[comboBox3.Text];
            dv.Rows.Clear();
            string csvText = "";
            if (File.Exists(fn))
            {
                using (var sr = new StreamReader(path: fn, encoding: Encoding.UTF8))
                {
                    T1_URI = sr.ReadLine();
                    T1_Title = sr.ReadLine();
                    csvText = sr.ReadToEnd();
                    sr.Close();
                }
            }
            stat_write("設定情報を読み込み中 ... 設定情報解析中.");
            //前後の改行を削除しておく
            csvText = csvText.Trim(new char[] { '\r', '\n' });

            //一行取り出すための正規表現
            System.Text.RegularExpressions.Regex regLine =
                new System.Text.RegularExpressions.Regex(
                "^.*(?:\\n|$)",
                System.Text.RegularExpressions.RegexOptions.Multiline);

            //1行のCSVから各フィールドを取得するための正規表現
            System.Text.RegularExpressions.Regex regCsv =
                new System.Text.RegularExpressions.Regex(
                "\\s*(\"(?:[^\"]|\"\")*\"|[^,]*)\\s*,",
                System.Text.RegularExpressions.RegexOptions.None);

            System.Text.RegularExpressions.Match mLine = regLine.Match(csvText);
            while (mLine.Success)
            {
                //一行取り出す
                string line = mLine.Value;
                //改行記号が"で囲まれているか調べる
                while ((CountString(line, "\"") % 2) == 1)
                {
                    mLine = mLine.NextMatch();
                    if (!mLine.Success)
                    {
                        return;
                    }
                    line += mLine.Value;
                }
                //行の最後の改行記号を削除
                line = line.TrimEnd(new char[] { '\r', '\n' });
                //最後に「,」をつける
                line += ",";

                //1つの行からフィールドを取り出す
                System.Text.RegularExpressions.Match m = regCsv.Match(line);
                int r = dv.Rows.Add();
                int c = 0;
                while (m.Success)
                {
                    string field = m.Groups[1].Value;
                    //前後の空白を削除
                    field = field.Trim();
                    //"で囲まれている時
                    if (field.StartsWith("\"") && field.EndsWith("\""))
                    {
                        //前後の"を取る
                        field = field.Substring(1, field.Length - 2);
                        //「""」を「"」にする
                        field = field.Replace("\"\"", "\"");
                    }
                    if (c < dv.ColumnCount)
                    {
                        dv.Rows[r].Cells[c].Value = field;
                        c++;
                    }
                    m = m.NextMatch();
                }
                mLine = mLine.NextMatch();
            }
            stat_write("設定情報を読み込み中 ... 完了.");
            stat_write("インターネットから通報情報をダウンロード中 ... (" + T1_URI + ")");

            var data = wc.DownloadData(T1_URI);
            var enc = Encoding.UTF8;
            wcDownloadString = enc.GetString(data);

            stat_write("インターネットから通報情報をダウンロード中 ... データ解析中");

            using (var wb = new WebBrowser())
            {
                wb.ScriptErrorsSuppressed = true;
                wb.Navigate("about:blank");
                wb.Document.OpenNew(false);
                wb.Document.Write(wcDownloadString);
                tzList.Clear();
                var eles = wb.Document.GetElementsByTagName("div");
                foreach (HtmlElement ele in eles)
                {
                    if (ele.GetAttribute("className").Equals("entry_body"))
                    {
                        var source = ele.InnerText.Split(new string[] { "\n" }, StringSplitOptions.None);
                        for (var r = 0; r < dv.Rows.Count; r++)
                        {
                            string str = (dv.Rows[r].Cells[1].Value ?? "").ToString();
                            string ms = "";
                            var item = dv.Rows[r];
                            if (str.Length > 0 && (item.Cells[2].Value ?? "").ToString().Length > 0)
                            {
                                string[] ids = str.Trim().Split(' ');
                                foreach (string istr in ids)
                                {
                                    int id = int.Parse(istr);
                                    Regex re = new Regex("[０-９Ａ-Ｚａ-ｚ：－　（）[］｛｝＠／．，]+");
                                    str = source[r];
                                    str = re.Replace(str, (MatchEvaluator)((Match m) => { return Strings.StrConv(m.Value, VbStrConv.Narrow, 0); }));
                                    str = str.Trim(new char[] { ' ' });
                                    if (!tzList.Keys.Contains(id))
                                    {
                                        tzList[id] = new Dictionary<string, string>();
                                    }
                                    switch ((item.Cells[3].Value ?? "").ToString())
                                    {
                                        case "RegExp":
                                            string pattern = (item.Cells[4].Value ?? "").ToString();
                                            var mc = Regex.Matches(str, pattern);
                                            foreach (Match m in mc)
                                            {
                                                if (m.Groups["name1"].Success) { tzList[id]["本名"] = m.Groups["name1"].Value.Trim(); }
                                                if (m.Groups["name2"].Success) { tzList[id]["通名"] = m.Groups["name2"].Value.Trim(); }
                                                if (m.Groups["workname"].Success) { tzList[id]["勤務先名称"] = m.Groups["workname"].Value.Trim(); }
                                                if (m.Groups["workaddr"].Success) { tzList[id]["勤務先住所"] = m.Groups["workaddr"].Value.Trim(); }
                                                if (m.Groups["worktelno"].Success) { tzList[id]["電話番号"] = m.Groups["worktelno"].Value.Trim(); }
                                            }
                                            break;
                                        case "Substr":
                                            var p = (item.Cells[4].Value ?? "").ToString().Split(' ');
                                            if (p.Length == 1)
                                            {
                                                ms = str.Substring(int.Parse(p[0]));
                                            }
                                            else if (p.Length == 2)
                                            {
                                                ms = str.Substring(int.Parse(p[0]), int.Parse(p[1]));
                                            }
                                            tzList[id][item.Cells[2].Value.ToString()] = ms;
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }
                        }
                        dataGridView1.Rows.Clear();
                        foreach (var c in tzList.Keys)
                        {
                            int lineno = dataGridView1.Rows.Add();
                            dataGridView1.Rows[lineno].Cells[0].Value = true;
                            dataGridView1.Rows[lineno].Cells[1].Value = "未(0)";
                            if (tzList[c].ContainsKey("通名"))
                            {
                                if(tzList[c].ContainsKey("本名")){
                                    dataGridView1.Rows[lineno].Cells[2].Value = tzList[c]["通名"] + "（" + tzList[c]["本名"] + "）";
                                }else{
                                    dataGridView1.Rows[lineno].Cells[2].Value = tzList[c]["通名"];
                                }
                            }else{
                                if(tzList[c].ContainsKey("本名")){
                                    dataGridView1.Rows[lineno].Cells[2].Value = tzList[c]["本名"];
                                }
                            }
                            if (tzList[c].ContainsKey("勤務先名称"))
                            {
                                dataGridView1.Rows[lineno].Cells[3].Value = tzList[c]["勤務先名称"];
                            }
                            if (tzList[c].ContainsKey("勤務先住所"))
                            {
                                dataGridView1.Rows[lineno].Cells[4].Value = PostNo.code(tzList[c]["勤務先住所"]);
                                dataGridView1.Rows[lineno].Cells[5].Value = tzList[c]["勤務先住所"];
                            }
                            if (tzList[c].ContainsKey("電話番号"))
                            {
                                dataGridView1.Rows[lineno].Cells[6].Value = TelNo.splits(tzList[c]["電話番号"]);
                            }
                        }

                    }
                }
            }

            stat_write("完了");
        }
        /// <summary>
        /// 指定された文字列内にある文字列が幾つあるか数える
        /// </summary>
        /// <param name="strInput">strFindが幾つあるか数える文字列</param>
        /// <param name="strFind">数える文字列</param>
        /// <returns>strInput内にstrFindが幾つあったか</returns>
        public static int CountString(string strInput, string strFind)
        {
            int foundCount = 0;
            int sPos = strInput.IndexOf(strFind);
            while (sPos > -1)
            {
                foundCount++;
                sPos = strInput.IndexOf(strFind, sPos + 1);
            }
            
            return foundCount;
        }

        private void webClientで取得したHTMLの表示ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var frm = new Form2(wcDownloadString))
            {
                frm.ShowDialog();
            }
        }

        private void webClientで取得したHTMLから本文抽出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var wb = new WebBrowser())
            {
                wb.ScriptErrorsSuppressed = true;
                wb.Navigate("about:blank");
                wb.Document.OpenNew(false);
                wb.Document.Write(wcDownloadString);
                var eles = wb.Document.GetElementsByTagName("div");
                foreach (HtmlElement ele in eles)
                {
                    if (ele.GetAttribute("className").Equals("entry_body"))
                    {
                        using (var frm = new Form2(ele.InnerText))
                        {
                            frm.ShowDialog();
                        }
                    }
                }
            }
        }

        private void regExTestToolStripMenuItem_Click(object sender, EventArgs e)
        {

            using (var wb = new WebBrowser())
            {
                wb.ScriptErrorsSuppressed = true;
                wb.Navigate("about:blank");
                wb.Document.OpenNew(false);
                wb.Document.Write(wcDownloadString);
                var eles = wb.Document.GetElementsByTagName("div");
                foreach (HtmlElement ele in eles)
                {
                    if (ele.GetAttribute("className").Equals("entry_body"))
                    {
                        using (var frm = new Form3(ele.InnerText))
                        {
                            frm.ShowDialog();
                        }
                    }
                }
            }
        }

        private void makeConfigFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var wb = new WebBrowser())
            {
                wb.ScriptErrorsSuppressed = true;
                wb.Navigate("about:blank");
                wb.Document.OpenNew(false);
                wb.Document.Write(wcDownloadString);
                var eles = wb.Document.GetElementsByTagName("div");
                foreach (HtmlElement ele in eles)
                {
                    if (ele.GetAttribute("className").Equals("entry_body"))
                    {
                        using (var frm = new mkconf(ele.InnerText))
                        {
                            frm.ShowDialog();
                        }
                    }
                }
            }

        }
        /// <summary>
        /// 個人情報の読込
        /// </summary>
        private void personalinfo_load()
        {
            string fn = System.Windows.Forms.Application.StartupPath + @"\個人情報.txt";
            if (System.IO.File.Exists(fn))
            {
                using (var sr = new System.IO.StreamReader(fn, encoding: Encoding.UTF8))
                {
                    textBox1.Text = sr.ReadLine();
                    textBox2.Text = sr.ReadLine();
                    textBox3.Text = sr.ReadLine();
                    maskedTextBox1.Text = sr.ReadLine();
                    maskedTextBox2.Text = sr.ReadLine();
                    maskedTextBox3.Text = sr.ReadLine();
                    maskedTextBox4.Text = sr.ReadLine();
                    comboBox1.SelectedIndex = int.Parse(sr.ReadLine());
                    comboBox2.SelectedIndex = int.Parse(sr.ReadLine());
                    sr.Close();
                }
            }
        }
        /// <summary>
        /// 個人情報の保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            string fn = System.Windows.Forms.Application.StartupPath + @"\個人情報.txt";
            using (var sw = new System.IO.StreamWriter(fn, append: false, encoding: Encoding.UTF8))
            {
                sw.WriteLine(textBox1.Text);
                sw.WriteLine(textBox2.Text);
                sw.WriteLine(textBox3.Text);
                sw.WriteLine(maskedTextBox1.Text);
                sw.WriteLine(maskedTextBox2.Text);
                sw.WriteLine(maskedTextBox3.Text);
                sw.WriteLine(maskedTextBox4.Text);
                sw.WriteLine(comboBox1.SelectedIndex.ToString());
                sw.WriteLine(comboBox2.SelectedIndex.ToString());
                sw.Close();
            }
        }

        /// <summary>
        /// 通報開始！！！！！！！！！！！！！！！！！！
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            // 証明書の無効なhttpsページを読み込んでもエラーにならないようにするためのおまじない。
            try
            {
                ServicePointManager.ServerCertificateValidationCallback =
                    new RemoteCertificateValidationCallback(
                        delegate
                        { return true; }
                   );
            }
            catch
            {
            }

            // 中断・継続の制御フラグ
            FLAG_procnext = true;
            string statprefix;
            for(int rowidx = 0; rowidx < dataGridView1.Rows.Count; rowidx++)
            {
                if (FLAG_procnext)
                {
                    statprefix = "[" + rowidx.ToString() + "] ";
                    if (((bool)dataGridView1.Rows[rowidx].Cells[0].Value) == true)
                    {
                        int phase = 1;
                        while (phase == 1)
                        {
                            if (FLAG_procnext)
                            {
                                stat_write(statprefix + "通報ページへアクセス中...");
                                var wb = this.webBrowser1;
                                wb.ScriptErrorsSuppressed = true;
                                wb.Navigate("https://www.immi-moj.go.jp/immimail/datainput.php");
                                wb_wait();
                                var hec = wb.Document.All;
                                var htm = hec.GetElementsByName("info");
                                htm[0].SetAttribute("selectedindex", "02");
                                wb_wait();
                                wb.Url = new Uri("javascript:" + Uri.EscapeDataString("send()") + ";");
                                wb_wait();
                                // あなたの情報
                                hec = wb.Document.All;
                                hec.GetElementsByName("usrname")[0].InnerText = (textBox1.Text.Length <= 40) ? textBox1.Text : textBox1.Text.Substring(0, 40);
                                wb_select(hec.GetElementsByName("sextype")[0], comboBox1.SelectedIndex.ToString("00"));
                                hec.GetElementsByName("age")[0].InnerText = (maskedTextBox1.Text.Length <= 3) ? maskedTextBox1.Text : maskedTextBox1.Text.Substring(0, 3);
                                wb_select(hec.GetElementsByName("usrpref")[0], comboBox2.SelectedIndex.ToString("00"));
                                hec.GetElementsByName("usrcity")[0].InnerText = (textBox2.Text.Length <= 100) ? textBox2.Text : textBox2.Text.Substring(0, 100);
                                hec.GetElementsByName("usrtelno1")[0].InnerText = (maskedTextBox2.Text.Length <= 5) ? maskedTextBox2.Text : maskedTextBox2.Text.Substring(0, 5);
                                hec.GetElementsByName("usrtelno2")[0].InnerText = (maskedTextBox3.Text.Length <= 4) ? maskedTextBox3.Text : maskedTextBox3.Text.Substring(0, 4);
                                hec.GetElementsByName("usrtelno3")[0].InnerText = (maskedTextBox4.Text.Length <= 4) ? maskedTextBox4.Text : maskedTextBox4.Text.Substring(0, 4);
                                hec.GetElementsByName("mail")[0].InnerText = (textBox3.Text.Length <= 100) ? textBox3.Text : textBox3.Text.Substring(0, 100);
                                // 違反者の情報
                                hec.GetElementsByName("details")[0].InnerText = "不法滞在の可能性";
                                hec.GetElementsByName("nationality")[0].InnerText = "韓国";
                                hec.GetElementsByName("nickname")[0].InnerText = ((dataGridView1.Rows[rowidx].Cells[2].Value ?? "").ToString().Length <= 100) ? (dataGridView1.Rows[rowidx].Cells[2].Value ?? "").ToString() : (dataGridView1.Rows[rowidx].Cells[2].Value ?? "").ToString().Substring(0, 100);
                                wb_select(hec.GetElementsByName("mencnt")[0], "16");
                                wb_select(hec.GetElementsByName("womencnt")[0], "16");
                                hec.GetElementsByName("workname")[0].InnerText = ((dataGridView1.Rows[rowidx].Cells[3].Value ?? "").ToString().Length <= 40) ? (dataGridView1.Rows[rowidx].Cells[3].Value ?? "").ToString() : (dataGridView1.Rows[rowidx].Cells[3].Value ?? "").ToString().Substring(0, 40);
                                wb_select(hec.GetElementsByName("workpref")[0], (dataGridView1.Rows[rowidx].Cells[4].Value ?? "00").ToString());
                                hec.GetElementsByName("workcity")[0].InnerText = PostNo.GetCity(((dataGridView1.Rows[rowidx].Cells[5].Value ?? "").ToString().Length <= 100) ? (dataGridView1.Rows[rowidx].Cells[5].Value ?? "").ToString() : (dataGridView1.Rows[rowidx].Cells[5].Value ?? "").ToString().Substring(0, 100));
                                if ((dataGridView1.Rows[rowidx].Cells[6].Value ?? "").ToString().Length > 0)
                                {
                                    string[] tels = TelNo.split(dataGridView1.Rows[rowidx].Cells[6].Value.ToString());
                                    hec.GetElementsByName("worktelno1")[0].InnerText = tels[0];
                                    hec.GetElementsByName("worktelno2")[0].InnerText = tels[1];
                                    hec.GetElementsByName("worktelno3")[0].InnerText = tels[2];
                                }
                                wb_select(hec.GetElementsByName("bustype")[0], "99");
                                hec.GetElementsByName("details")[0].InvokeMember("keypress");
                                foreach (HtmlElement ele in wb.Document.GetElementsByTagName("input"))
                                {
                                    if (ele.DomElement is mshtml.HTMLInputElement)
                                    {
                                        mshtml.HTMLInputElement ie = (mshtml.HTMLInputElement)ele.DomElement;
                                        if (ie.value == "確認")
                                        {
                                            stat_write(statprefix + "入力完了。確認ボタンClick。");
                                            Application.DoEvents();
                                            for (int cnttime = 0; cnttime < wait_inputpage; cnttime++)
                                            {
                                                System.Threading.Thread.Sleep(100);
                                                Application.DoEvents();
                                            }
                                            ie.click();
                                        }
                                    }
                                }
                                wb_wait();
                                if (wb.DocumentTitle == "入国管理局ホームページ～入力情報確認～")
                                {
                                    phase = 2;
                                    Application.DoEvents();
                                    for (int cnttime = 0; cnttime < wait_confirmpage; cnttime++)
                                    {
                                        System.Threading.Thread.Sleep(100);
                                        Application.DoEvents();
                                    }
                                }
                                else
                                {
                                    stat_write(statprefix + "エラーページが表示されました。数秒後にリトライします。", Color.Red);
                                    Application.DoEvents();
                                    for (int cnttime = 0; cnttime < wait_errpage; cnttime++)
                                    {
                                        System.Threading.Thread.Sleep(100);
                                        Application.DoEvents();
                                    }
                                    phase = 1;
                                }
                                while (phase == 2 && FLAG_procnext)
                                {
                                    hec = wb.Document.All;
                                    if (hec.GetElementsByName("mailb")[0].DomElement is mshtml.HTMLInputElement)
                                    {
                                        stat_write(statprefix + "確認完了。送信ボタンClick。");
                                        mshtml.HTMLInputElement ie = (mshtml.HTMLInputElement)hec.GetElementsByName("mailb")[0].DomElement;
                                        ie.click();
                                    }
                                    wb_wait();
                                    if (wb.DocumentTitle == "入国管理局ホームページ～送信完了～")
                                    {
                                        stat_write(statprefix + "送信完了。");
                                        phase = 3;
                                        Application.DoEvents();
                                        for (int cnttime = 0; cnttime < wait_finishpage; cnttime++)
                                        {
                                            System.Threading.Thread.Sleep(100);
                                            Application.DoEvents();
                                        }
                                    }
                                    else
                                    {
                                        stat_write(statprefix + "エラーページが表示されました。数秒後にリトライします。", Color.Red);
                                        Application.DoEvents();
                                        for (int cnttime = 0; cnttime < wait_errpage; cnttime++)
                                        {
                                            System.Threading.Thread.Sleep(100);
                                            Application.DoEvents();
                                        }
                                        phase = 1;
                                    }
                                    while (phase == 3)
                                    {
                                        hec = wb.Document.All;
                                        string acknumber="";

                                        //一行取り出すための正規表現
                                        System.Text.RegularExpressions.Regex reg =
                                            new System.Text.RegularExpressions.Regex(
                                            @".*本情報の受付番号は([\d]+)です。.*",
                                            System.Text.RegularExpressions.RegexOptions.Singleline);
                                        foreach (string txt in wb.Document.Body.InnerText.Split(new string[] { "\n" }, StringSplitOptions.None))
                                        {
                                            Match m = reg.Match(txt);
                                            if(m.Success)
                                            {
                                                acknumber = m.Groups[1].Value;
                                            }
                                        }
                                        dataGridView1.Rows[rowidx].Cells[1].Value = "済(" + acknumber + ")";
                                        dataGridView1.Rows[rowidx].Cells[0].Value = false;
                                        Application.DoEvents();
                                        for (int cnttime = 0; cnttime < 10; cnttime++)
                                        {
                                            System.Threading.Thread.Sleep(100);
                                            Application.DoEvents();
                                        }
                                        phase = 0;
                                    }
                                }
                                if (!FLAG_procnext)
                                {
                                    stat_write("中断しました。");
                                    return;
                                }
                            }
                            else
                            {
                                stat_write("中断しました。");
                                return;
                            }
                        }
                    }
                }
                else
                {
                    stat_write("");
                }
            }
            /**********
            ■あなたの情報
            名前<input name="usrname" maxlength="40" onkeypress="return checkKey()">
            性別<select name="sextype">
            年齢<input name="age"     maxlength="3"  onkeypress="return checkKey()">
            住所(都道府県)<select name="usrpref">
            住所(市区町村)<input name="usrcity" maxlength="100" onkeypress="return checkKey()">
            電話番号
                <input name="usrtelno1" value="" size="5" maxlength="5" onkeypress="return checkKey()">
                <input name="usrtelno2" value="" size="5" maxlength="4" onkeypress="return checkKey()">
                <input name="usrtelno3" value="" size="5" maxlength="4" onkeypress="return checkKey()">
            e-mail<input name="mail" value="" size="100" maxlength="60" onkeypress="return checkKey()">

            ■提供情報
            提供内容<select name="info" onchange="send();">

            ■違反者と思われる人に関する情報
            通報動機，違反を知った経緯・状況・人物を特定きる情報等<必須項目>
                <textarea name="details" onkeypress="return checkKey()" class="fs">
            国籍	<input name="nationality" maxlength="100" onkeypress="return checkKey()" type="text">
            名前(ニックネーム)
                <input name="nickname" maxlength="100" onkeypress="return checkKey()" type="text">
            人数
            男	<select name="mencnt"><option value="16">31人以上</option>
            女	<select name="womencnt"><option value="16">31人以上</option>

            ■違反者と思われる人の働いている場所又は見かけた場所等に関する情報
            名称<input name="workname" maxlength="40" onkeypress="return checkKey()">
            住所(都道府県)<必須項目><select name="workpref">
            住所(市区町村)<必須項目><input name="workcity" maxlength="100" onkeypress="return checkKey()" >
            電話番号
                <input name="worktelno1" value="" size="5" maxlength="5" onkeypress="return checkKey()">
                <input name="worktelno2" value="" size="5" maxlength="4" onkeypress="return checkKey()">
                <input name="worktelno3" value="" size="5" maxlength="4" onkeypress="return checkKey()">
            業種<必須項目>
                <select name="bustype"><option value="99">その他</option></select>
            営業時間
            <select name="sthour">：<select name="stminute">
            ～
            <select name="edhour">：<select name="edminute">
            休業日	<input name="holiday" size="40" value="" maxlength="40" onkeypress="return checkKey()" >

             **********/
        }
        /// <summary>
        /// ステータスバーの更新
        /// </summary>
        /// <param name="msg"></param>
        private void stat_write(string msg)
        {
            this.toolStripStatusLabel1.Text = msg;
            this.toolStripStatusLabel1.ForeColor = Color.Black;
            this.listBox1.Items.Insert(0, msg);
            Application.DoEvents();
            for (int cnttime = 0; cnttime < 5; cnttime++)
            {
                System.Threading.Thread.Sleep(100);
                Application.DoEvents();
            }
        }
        /// <summary>
        /// ステータスバーの更新（色つき）
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="c"></param>
        private void stat_write(string msg, Color c)
        {
            this.toolStripStatusLabel1.Text = msg;
            this.toolStripStatusLabel1.ForeColor = c;
            this.listBox1.Items.Insert(0, msg);
            Application.DoEvents();
            for (int cnttime = 0; cnttime < 5; cnttime++)
            {
                System.Threading.Thread.Sleep(100);
                Application.DoEvents();
            }
        }
        /// <summary>
        /// WebBrowserのコンボボックスから指定のvalueを選択する
        /// </summary>
        /// <param name="sele"></param>
        /// <param name="val"></param>
        private void wb_select(HtmlElement sele, string val)
        {
            foreach (HtmlElement e in sele.GetElementsByTagName("option"))
            {
                if(e.GetAttribute("value")==val)
                {
                    e.SetAttribute("selected", "true");
                }
            }
        }
        /// <summary>
        /// WebBrowserが準備完了となるのを待つ
        /// </summary>
        private void wb_wait()
        {
            var web = webBrowser1;
            System.Threading.Thread.Sleep(250);
            Application.DoEvents();
            try
            {
                while (
                    web.IsBusy ||
                    web.ReadyState != WebBrowserReadyState.Complete ||
                    web.Document.Body.InnerHtml == null)
                {
                    System.Threading.Thread.Sleep(250);
                    Application.DoEvents();
                }
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// アドレスバー更新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void webBrowser1_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            textBox4.Text = webBrowser1.Url.ToString();
        }

        private void telNumberTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var i = Interaction.InputBox("電話番号を入力すると、ハイフン区切りを自動で追加します。");
            Interaction.MsgBox(TelNo.splits(i));
        }

        /// <summary>
        /// データグリッドビューの便利操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if(e.KeyCode ==Keys.Delete || e.KeyCode == Keys.Back)
                {
                    var range =dataGridView1.SelectedCells;
                    foreach (DataGridViewCell cell in range)
                    {
                        cell.Value = "";
                    }
                    
                }
                if (e.Control && e.KeyCode == Keys.C)
                {
                    Clipboard.SetDataObject(dataGridView1.GetClipboardContent());
                    var range = dataGridView1.SelectedCells;
                    int col_count = 0;
                    int row_count = 0;
                    int col_min = 999;
                    int col_max = 0;
                    int row_min = 999;
                    int row_max = 0;
                    foreach (DataGridViewCell cell in range)
                    {
                        if (col_min > cell.ColumnIndex) col_min = cell.ColumnIndex;
                        if (col_max < cell.ColumnIndex) col_max = cell.ColumnIndex;
                        if (row_min > cell.RowIndex) row_min = cell.RowIndex;
                        if (row_max < cell.RowIndex) row_max = cell.RowIndex;
                    }
                    col_count = col_max - col_min + 1;
                    row_count = row_max - row_min + 1;

                    int[,] pos = new int[row_count, col_count];
                    for (int idx = 0; idx < range.Count; idx++)
                    {
                        pos[range[idx].RowIndex - row_min, range[idx].ColumnIndex - col_min] = idx;
                    }

                    var sb = new StringBuilder();
                    for (int r = 0; r < row_count; r++)
                    {
                        for (int c = 0; c < col_count; c++)
                        {
                            var field = (range[pos[r,c]].Value ?? "").ToString();
                            field = EncloseDoubleQuotesIfNeed(field);
                            sb.Append(field);
                            if (c < col_count - 1)
                            {
                                sb.Append(",");
                            }
                        }
                        sb.AppendLine();
                    }
                    try
                    {
                        byte[] bs = System.Text.Encoding.Default.GetBytes(sb.ToString());
                        System.IO.MemoryStream ms = new System.IO.MemoryStream(bs);
                        //CSV形式でクリップボードに貼り付ける
                        DataObject data = new DataObject(DataFormats.CommaSeparatedValue, ms);
                        //クリップボードに貼り付ける
                        Clipboard.SetDataObject(data);
                    }
                    catch { }
                }
                if (e.Control && e.KeyCode == Keys.V)
                {
                    //クリップボードのデータを取得する
                    IDataObject data = Clipboard.GetDataObject();
                    //データがある時
                    if (data != null)
                    {
                        var fmts = data.GetFormats();
                        if (fmts.Contains(DataFormats.CommaSeparatedValue))
                        {
                            //MemoryStreamとして取得する
                            byte[] bs = System.Text.Encoding.Default.GetBytes((string)data.GetData(DataFormats.CommaSeparatedValue));
                            System.IO.MemoryStream ms = new System.IO.MemoryStream(bs);
                            if (ms != null)
                            {
                                //エンコードするためのStreamReaderを作成する
                                System.IO.StreamReader sr =
                                    new System.IO.StreamReader(ms, System.Text.Encoding.Default);
                                //エンコードして、文字列に変換する
                                string csvText = sr.ReadToEnd();


                                //前後の改行を削除しておく
                                csvText = csvText.Trim(new char[] { '\r', '\n' });

                                //一行取り出すための正規表現
                                System.Text.RegularExpressions.Regex regLine =
                                    new System.Text.RegularExpressions.Regex(
                                    "^.*(?:\\n|$)",
                                    System.Text.RegularExpressions.RegexOptions.Multiline);

                                //1行のCSVから各フィールドを取得するための正規表現
                                System.Text.RegularExpressions.Regex regCsv =
                                    new System.Text.RegularExpressions.Regex(
                                    "\\s*(\"(?:[^\"]|\"\")*\"|[^,]*)\\s*,",
                                    System.Text.RegularExpressions.RegexOptions.None);

                                System.Text.RegularExpressions.Match mLine = regLine.Match(csvText);
                                int row_index = dataGridView1.SelectedCells[0].RowIndex;
                                int col_index = dataGridView1.SelectedCells[0].ColumnIndex;
                                // 行数を見て追加
                                int row_num = csvText.Split(new string[] { "\r\n" }, StringSplitOptions.None).Count();
                                if (row_index + row_num > dataGridView1.Rows.Count)
                                {
                                    for (int j = 0; j < row_num + row_index - dataGridView1.Rows.Count; j++)
                                    {
                                        dataGridView1.Rows.Add();
                                    }
                                }
                                while (mLine.Success)
                                {
                                    //一行取り出す
                                    string line = mLine.Value;
                                    //改行記号が"で囲まれているか調べる
                                    while ((CountString(line, "\"") % 2) == 1)
                                    {
                                        mLine = mLine.NextMatch();
                                        if (!mLine.Success)
                                        {
                                            return;
                                        }
                                        line += mLine.Value;
                                    }
                                    //行の最後の改行記号を削除
                                    line = line.TrimEnd(new char[] { '\r', '\n' });
                                    //最後に「,」をつける
                                    line += ",";

                                    //1つの行からフィールドを取り出す
                                    System.Text.RegularExpressions.Match m = regCsv.Match(line);

                                    int c = col_index;
                                    while (m.Success)
                                    {
                                        string field = m.Groups[1].Value;
                                        //前後の空白を削除
                                        field = field.Trim();
                                        //"で囲まれている時
                                        if (field.StartsWith("\"") && field.EndsWith("\""))
                                        {
                                            //前後の"を取る
                                            field = field.Substring(1, field.Length - 2);
                                            //「""」を「"」にする
                                            field = field.Replace("\"\"", "\"");
                                        }
                                        if (c < dataGridView1.ColumnCount)
                                        {
                                            dataGridView1.Rows[row_index].Cells[c].Value = field;
                                            c++;
                                        }
                                        m = m.NextMatch();
                                    }
                                    mLine = mLine.NextMatch();
                                    row_index++;
                                }

                            }
                        }    
                    }
                }


            }
            catch { }
        }
        /// <summary>
        /// 必要ならば、文字列をダブルクォートで囲む
        /// </summary>
        private string EncloseDoubleQuotesIfNeed(string field)
        {
            if (NeedEncloseDoubleQuotes(field))
            {
                return EncloseDoubleQuotes(field);
            }
            return field;
        }

        /// <summary>
        /// 文字列をダブルクォートで囲む
        /// </summary>
        private string EncloseDoubleQuotes(string field)
        {
            if (field.IndexOf('"') > -1)
            {
                //"を""とする
                field = field.Replace("\"", "\"\"");
            }
            return "\"" + field + "\"";
        }

        /// <summary>
        /// 文字列をダブルクォートで囲む必要があるか調べる
        /// </summary>
        private bool NeedEncloseDoubleQuotes(string field)
        {
            return field.IndexOf('"') > -1 ||
                field.IndexOf(',') > -1 ||
                field.IndexOf('\r') > -1 ||
                field.IndexOf('\n') > -1 ||
                field.StartsWith(" ") ||
                field.StartsWith("\t") ||
                field.EndsWith(" ") ||
                field.EndsWith("\t");
        }

        /// <summary>
        /// 中断だ！！！
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_Click(object sender, EventArgs e)
        {
            FLAG_procnext = false;
        }
    }
    /// <summary>
    /// 電話番号を適切な位置で区切る
    /// </summary>
    public static class TelNo
    {
        public static string[] split(string telno)
        {
            var res = new string[3];
            res[0] = "";
            var dic = new Dictionary<int, Dictionary<string, int>>();
            dic[5] = new Dictionary<string, int>{
                {"01564",1},{"01558",1},{"01586",1},{"01587",1},{"01634",1},{"01632",1},{"01547",1},{"05769",1},{"04992",1},{"04994",1},{"01456",1},{"01457",1},{"01466",1},{"01635",1},{"09496",1},
                {"08477",1},{"08512",1},{"08396",1},{"08388",1},{"08387",1},{"08514",1},{"07468",1},{"01655",1},{"01648",1},{"01656",1},{"01658",1},{"05979",1},{"04996",1},{"01654",1},{"01372",1},
                {"01374",1},{"09969",1},{"09802",1},{"09912",1},{"09913",1},{"01398",1},{"01377",1},{"01267",1},{"04998",1},{"01397",1},{"01392",1},
            };
            dic[4] = new Dictionary<string, int>{
                {"0768",2},{"0770",2},{"0772",2},{"0774",2},{"0773",2},{"0767",2},{"0771",2},{"0765",2},{"0748",2},{"0747",2},{"0746",2},{"0826",2},{"0749",2},{"0776",2},{"0763",2},
                {"0761",2},{"0766",2},{"0778",2},{"0824",2},{"0797",2},{"0796",2},{"0555",2},{"0823",2},{"0798",2},{"0554",2},{"0820",2},{"0795",2},{"0556",2},{"0791",2},{"0790",2},
                {"0779",2},{"0558",2},{"0745",2},{"0794",2},{"0557",2},{"0799",2},{"0738",2},{"0567",2},{"0568",2},{"0585",2},{"0586",2},{"0566",2},{"0564",2},{"0565",2},{"0587",2},
                {"0584",2},{"0581",2},{"0572",2},{"0574",2},{"0573",2},{"0575",2},{"0576",2},{"0578",2},{"0577",2},{"0569",2},{"0594",2},{"0827",2},{"0736",2},{"0735",2},{"0725",2},
                {"0737",2},{"0739",2},{"0743",2},{"0742",2},{"0740",2},{"0721",2},{"0599",2},{"0561",2},{"0562",2},{"0563",2},{"0595",2},{"0596",2},{"0598",2},{"0597",2},{"0744",2},
                {"0852",2},{"0956",2},{"0955",2},{"0954",2},{"0952",2},{"0957",2},{"0959",2},{"0966",2},{"0965",2},{"0964",2},{"0950",2},{"0949",2},{"0942",2},{"0940",2},{"0930",2},
                {"0943",2},{"0944",2},{"0948",2},{"0947",2},{"0946",2},{"0967",2},{"0968",2},{"0987",2},{"0986",2},{"0985",2},{"0984",2},{"0993",2},{"0994",2},{"0997",2},{"0996",2},
                {"0995",2},{"0983",2},{"0982",2},{"0973",2},{"0972",2},{"0969",2},{"0974",2},{"0977",2},{"0980",2},{"0979",2},{"0978",2},{"0920",2},{"0898",2},{"0855",2},{"0854",2},
                {"0853",2},{"0553",2},{"0856",2},{"0857",2},{"0863",2},{"0859",2},{"0858",2},{"0848",2},{"0847",2},{"0835",2},{"0834",2},{"0833",2},{"0836",2},{"0837",2},{"0846",2},
                {"0845",2},{"0838",2},{"0865",2},{"0866",2},{"0892",2},{"0889",2},{"0887",2},{"0893",2},{"0894",2},{"0897",2},{"0896",2},{"0895",2},{"0885",2},{"0884",2},{"0869",2},
                {"0868",2},{"0867",2},{"0875",2},{"0877",2},{"0883",2},{"0880",2},{"0879",2},{"0829",2},{"0550",2},{"0228",2},{"0226",2},{"0225",2},{"0224",2},{"0229",2},{"0233",2},
                {"0237",2},{"0235",2},{"0234",2},{"0223",2},{"0220",2},{"0192",2},{"0191",2},{"0187",2},{"0193",2},{"0194",2},{"0198",2},{"0197",2},{"0195",2},{"0238",2},{"0240",2},
                {"0260",2},{"0259",2},{"0258",2},{"0257",2},{"0261",2},{"0263",2},{"0266",2},{"0265",2},{"0264",2},{"0256",2},{"0255",2},{"0243",2},{"0242",2},{"0241",2},{"0244",2},
                {"0246",2},{"0254",2},{"0248",2},{"0247",2},{"0186",2},{"0185",2},{"0144",2},{"0143",2},{"0142",2},{"0139",2},{"0145",2},{"0146",2},{"0154",2},{"0153",2},{"0152",2},
                {"0138",2},{"0137",2},{"0125",2},{"0124",2},{"0123",2},{"0126",2},{"0133",2},{"0136",2},{"0135",2},{"0134",2},{"0155",2},{"0156",2},{"0176",2},{"0175",2},{"0174",2},
                {"0178",2},{"0179",2},{"0184",2},{"0183",2},{"0182",2},{"0173",2},{"0172",2},{"0162",2},{"0158",2},{"0157",2},{"0163",2},{"0164",2},{"0167",2},{"0166",2},{"0165",2},
                {"0267",2},{"0250",2},{"0533",2},{"0422",2},{"0532",2},{"0531",2},{"0436",2},{"0428",2},{"0536",2},{"0299",2},{"0294",2},{"0293",2},{"0475",2},{"0295",2},{"0297",2},
                {"0296",2},{"0495",2},{"0438",2},{"0466",2},{"0465",2},{"0467",2},{"0478",2},{"0476",2},{"0470",2},{"0463",2},{"0479",2},{"0493",2},{"0494",2},{"0439",2},{"0268",2},
                {"0480",2},{"0460",2},{"0538",2},{"0537",2},{"0539",2},{"0279",2},{"0548",2},{"0280",2},{"0282",2},{"0278",2},{"0277",2},{"0269",2},{"0270",2},{"0274",2},{"0276",2},
                {"0283",2},{"0551",2},{"0289",2},{"0287",2},{"0547",2},{"0288",2},{"0544",2},{"0545",2},{"0284",2},{"0291",2},{"0285",2},{"0120",3},{"0570",3},{"0800",3},{"0990",3},
            };
            dic[3] = new Dictionary<string, int>{
                {"099",3},{"054",3},{"058",3},{"098",3},{"095",3},{"097",3},{"052",3},{"053",3},{"011",3},{"096",3},{"049",3},{"015",3},{"048",3},{"072",3},{"084",3},{"028",3},{"024",3},
                {"076",3},{"023",3},{"047",3},{"029",3},{"075",3},{"025",3},{"055",3},{"026",3},{"079",3},{"082",3},{"027",3},{"078",3},{"077",3},{"083",3},{"022",3},{"086",3},{"089",3},
                {"045",3},{"044",3},{"092",3},{"046",3},{"017",3},{"093",3},{"059",3},{"073",3},{"019",3},{"087",3},{"042",3},{"018",3},{"043",3},{"088",3},{"050",4},
                {"090",4},{"080",4},{"070",4},{"020",4},
            };
            dic[2] = new Dictionary<string, int>{
                {"04",4},{"03",4},{"06",4}
            };
            telno = Regex.Replace(telno, @"[^\d]", "");
            var ks = dic.OrderByDescending((k) => k.Key);
            foreach (var len in ks)
            {
                var area = telno.Substring(0, len.Key);
                if (len.Value.ContainsKey(area))
                {
                    res[0] = area;
                    res[1] = telno.Substring(len.Key, len.Value[area]);
                    res[2] = telno.Substring(len.Key + len.Value[area]);
                }
            }
            if (res[0].Length == 0)
            {
                res[0] = telno.Substring(0, 5);
                res[1] = telno.Substring(5, 4);
                res[2] = telno.Substring(9, 4);
            }
            return res;
        }
        public static string splits(string telno)
        {
            string[] s = split(telno);
            return string.Join("-", s);
        }
    }
    /// <summary>
    /// 都道府県の選択IDを取得する
    /// </summary>
    public static class PostNo
    {
        public static string code(string addr)
        {
            addr = addr.Substring(0, (addr.Length>3)?3:addr.Length);
            var dic = new Dictionary<string, string>
            {
                {"---","00"},{"北海道","01"},{"青森県","02"},{"岩手県","03"},{"宮城県","04"},{"秋田県","05"},{"山形県","06"},{"福島県","07"},{"茨城県","08"},{"栃木県","09"},
                {"群馬県","10"},{"埼玉県","11"},{"千葉県","12"},{"東京都","13"},{"神奈川","14"},{"新潟県","15"},{"富山県","16"},{"石川県","17"},{"福井県","18"},{"山梨県","19"},
                {"長野県","20"},{"岐阜県","21"},{"静岡県","22"},{"愛知県","23"},{"三重県","24"},{"滋賀県","25"},{"京都府","26"},{"大阪府","27"},{"兵庫県","28"},{"奈良県","29"},
                {"和歌山","30"},{"鳥取県","31"},{"島根県","32"},{"岡山県","33"},{"広島県","34"},{"山口県","35"},{"徳島県","36"},{"香川県","37"},{"愛媛県","38"},{"高知県","39"},
                {"福岡県","40"},{"佐賀県","41"},{"大分県","42"},{"長崎県","43"},{"熊本県","44"},{"宮崎県","45"},{"鹿児島","46"},{"沖縄県","47"},
                {"横浜市","14"},{"大阪市","27"},{"神戸市","28"},{"福岡市","40"},{"京都市","26"},

            };
            if(dic.ContainsKey(addr))
            {
                return dic[addr];
            }
            else
            {
                return "13"; // wakaranai = tokyo
            }
        }
        /// <summary>
        /// 市町村名以降の住所を抽出する
        /// </summary>
        /// <param name="addr"></param>
        /// <returns></returns>
        public static string GetCity(string addr)
        {
            int len = addr.Length;
            if (len >= 4)
            {
                len = 4;
            }
            string pref = addr.Substring(0, len);
            if (pref.IndexOf("都") > 0) return addr.Substring(pref.IndexOf("都") + "都".Length);
            if (pref.IndexOf("道") > 0) return addr.Substring(pref.IndexOf("道") + "道".Length);
            if (pref.IndexOf("府") > 0) return addr.Substring(pref.IndexOf("府") + "府".Length);
            if (pref.IndexOf("県") > 0) return addr.Substring(pref.IndexOf("県") + "県".Length);
            return addr;
        }
    }
}
