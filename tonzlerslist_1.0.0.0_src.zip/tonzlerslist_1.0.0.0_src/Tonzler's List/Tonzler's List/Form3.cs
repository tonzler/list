﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;

namespace Tonzler_s_List
{
    public partial class Form3 : Form
    {
        int index;
        string str;
        System.Text.RegularExpressions.MatchCollection mc;

        public Form3()
        {
            InitializeComponent();
        }
        public Form3(string source)
        {
            InitializeComponent();
            index = 0;
            str = source;
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            var dat = str.Split(new string[] { "\n" }, StringSplitOptions.None);
            foreach (var s in dat)
            {
                dataGridView1.Rows.Add(); index++;
                dataGridView1.Rows[index - 1].Cells[0].Value = (index).ToString();
                dataGridView1.Rows[index - 1].Cells[1].Value = s;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] pattern_nickname;
            string[] pattern_workaddr;
            string[] pattern_workname;
            string[] pattern_telno;
            string nickname = null;
            string workname = null;
            string workaddr = null;
            string telno = null;

            pattern_nickname = new string[] { ".*【氏名】(?<>.*)$" };
            pattern_workname = new string[] { ".*【所属団体】(?<>.*)$", "【所属団体名】(?<>.*)$" };
            pattern_workaddr = new string[] { ".*【所属団体所在地】(?<>.*)$", "【団体住所】(?<>.*)$", };
            pattern_telno = new string[] { ""};

            for (var i = 0; i < dataGridView1.Rows.Count; i++)
            {
                string str = (dataGridView1.Rows[i].Cells[1].Value as string)??"";
                Regex re = new Regex("[０-９Ａ-Ｚａ-ｚ：－　（）[］｛｝＠／．，]+");
                str = re.Replace(str, (MatchEvaluator)((Match m) => { return Strings.StrConv(m.Value, VbStrConv.Narrow, 0); }));
                str = str.Trim(new char[] { ' ' });
                if (str.Length == 0)
                {
                    if ((nickname ?? workaddr ?? workname ?? telno) != null)
                    {
                        dataGridView1.Rows[i].Cells[2].Value = "nickname=" + nickname ?? "" + "; workname=" + workname ?? "" + "; workaddr=" + workaddr ?? "" + "; telno=" + telno ?? "" + ";";
                        nickname = null;
                        workaddr = null;
                        workname = null;
                        telno = null;
                    }
                }
                mc = System.Text.RegularExpressions.Regex.Matches((dataGridView1.Rows[i].Cells[1].Value as string)??"", textBox1.Text);


                try { nickname = mc[0].Groups["nickname"].Value; }
                catch { }
                try { workname = mc[0].Groups["workname"].Value; }
                catch { }
                try { workaddr = mc[0].Groups["workaddr"].Value; }
                catch { }
                dataGridView1.Rows[i].Cells[2].Value = "nickname=" + nickname ?? "" + "; workname=" + workname ?? "" + "; workaddr=" + workaddr ?? "" + ";"; 
            }
        }
    }
}
