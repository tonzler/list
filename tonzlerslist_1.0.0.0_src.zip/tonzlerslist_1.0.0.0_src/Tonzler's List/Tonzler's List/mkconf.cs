﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;


namespace Tonzler_s_List
{
    public partial class mkconf : Form
    {
        Dictionary<int,Dictionary<string,string>> tzList; 
        public mkconf()
        {
            InitializeComponent();
        }

        public mkconf(string source)
        {
            InitializeComponent();
            tzList = new Dictionary<int, Dictionary<string, string>>();
            int num = 1;
            var data = source.Split(new string[] { "\n" }, StringSplitOptions.None);
            foreach (var str in data)
            {
                int i = dataGridView1.Rows.Add();
                dataGridView1.Rows[i].Cells[0].Value = (num++).ToString();
                dataGridView1.Rows[i].Cells[dataGridView1.ColumnCount - 1].Value = str;
            }
        }

        ~mkconf()
        {
            if (tzList != null)
            {
                foreach (var c in tzList.Keys)
                {
                    if (tzList[c] != null)
                    {
                        tzList[c].Clear();
                        tzList[c] = null;
                    }
                }
                tzList.Clear();
                tzList = null;
                GC.Collect();
            }
        }
        private void mkconf_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var diag = new SaveFileDialog())
            {
                diag.InitialDirectory = System.Windows.Forms.Application.StartupPath + @"\conf\";
                diag.Filter = "Textファイル(*.txt)|*.txt|すべてのファイル(*.*)|*.*";
                diag.FilterIndex = 1;
                diag.RestoreDirectory = true;
                diag.OverwritePrompt = false;
                if(diag.ShowDialog() == DialogResult.OK)
                {
                    textBox1.Text = diag.FileName;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            string csvText = "";
            if (File.Exists(textBox1.Text))
            {
                using (var sr = new StreamReader(path: textBox1.Text, encoding: Encoding.UTF8))
                {
                    textBox2.Text = sr.ReadLine();
                    textBox3.Text = sr.ReadLine();

                    csvText = sr.ReadToEnd();
                    sr.Close();
                }
            }
            //前後の改行を削除しておく
            csvText = csvText.Trim(new char[] { '\r', '\n' });

            //一行取り出すための正規表現
            System.Text.RegularExpressions.Regex regLine =
                new System.Text.RegularExpressions.Regex(
                "^.*(?:\\n|$)",
                System.Text.RegularExpressions.RegexOptions.Multiline);

            //1行のCSVから各フィールドを取得するための正規表現
            System.Text.RegularExpressions.Regex regCsv =
                new System.Text.RegularExpressions.Regex(
                "\\s*(\"(?:[^\"]|\"\")*\"|[^,]*)\\s*,",
                System.Text.RegularExpressions.RegexOptions.None);

            System.Text.RegularExpressions.Match mLine = regLine.Match(csvText);
            while (mLine.Success)
            {
                //一行取り出す
                string line = mLine.Value;
                //改行記号が"で囲まれているか調べる
                while ((CountString(line, "\"") % 2) == 1)
                {
                    mLine = mLine.NextMatch();
                    if (!mLine.Success)
                    {
                        return;
                    }
                    line += mLine.Value;
                }
                //行の最後の改行記号を削除
                line = line.TrimEnd(new char[] { '\r', '\n' });
                //最後に「,」をつける
                line += ",";

                //1つの行からフィールドを取り出す
                System.Text.RegularExpressions.Match m = regCsv.Match(line);
                int r = dataGridView1.Rows.Add();
                int c = 0;
                while (m.Success)
                {
                    string field = m.Groups[1].Value;
                    //前後の空白を削除
                    field = field.Trim();
                    //"で囲まれている時
                    if (field.StartsWith("\"") && field.EndsWith("\""))
                    {
                        //前後の"を取る
                        field = field.Substring(1, field.Length - 2);
                        //「""」を「"」にする
                        field = field.Replace("\"\"", "\"");
                    }
                    if (c < dataGridView1.ColumnCount)
                    {
                        dataGridView1.Rows[r].Cells[c].Value = field;
                        c++;
                    }
                    m = m.NextMatch();
                }
                mLine = mLine.NextMatch();
            }
            return;


        }

        /// <summary>
        /// 指定された文字列内にある文字列が幾つあるか数える
        /// </summary>
        /// <param name="strInput">strFindが幾つあるか数える文字列</param>
        /// <param name="strFind">数える文字列</param>
        /// <returns>strInput内にstrFindが幾つあったか</returns>
        public static int CountString(string strInput, string strFind)
        {
            int foundCount = 0;
            int sPos = strInput.IndexOf(strFind);
            while (sPos > -1)
            {
                foundCount++;
                sPos = strInput.IndexOf(strFind, sPos + 1);
            }

            return foundCount;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            var sb = new StringBuilder();
            {
                sb.AppendLine(textBox2.Text);
                sb.AppendLine(textBox3.Text);
                for (int r = 0; r < this.dataGridView1.RowCount; r++)
                {
                    for (int c = 0; c < this.dataGridView1.ColumnCount; c++)
                    {
                        var field = (this.dataGridView1.Rows[r].Cells[c].Value ?? "").ToString();
                        field = EncloseDoubleQuotesIfNeed(field);
                        sb.Append(field);
                        if (c < this.dataGridView1.ColumnCount - 1)
                        {
                            sb.Append(",");
                        }
                    }
                    sb.AppendLine();
                }
                try
                {
                    using (var sw = new StreamWriter(textBox1.Text, append: false, encoding: System.Text.Encoding.UTF8))
                    {
                        sw.Write(sb.ToString());
                        sw.Close();
                    }
                }
                catch { }
            }

        }

        /// <summary>
        /// 必要ならば、文字列をダブルクォートで囲む
        /// </summary>
        private string EncloseDoubleQuotesIfNeed(string field)
        {
            if (NeedEncloseDoubleQuotes(field))
            {
                return EncloseDoubleQuotes(field);
            }
            return field;
        }

        /// <summary>
        /// 文字列をダブルクォートで囲む
        /// </summary>
        private string EncloseDoubleQuotes(string field)
        {
            if (field.IndexOf('"') > -1)
            {
                //"を""とする
                field = field.Replace("\"", "\"\"");
            }
            return "\"" + field + "\"";
        }

        /// <summary>
        /// 文字列をダブルクォートで囲む必要があるか調べる
        /// </summary>
        private bool NeedEncloseDoubleQuotes(string field)
        {
            return field.IndexOf('"') > -1 ||
                field.IndexOf(',') > -1 ||
                field.IndexOf('\r') > -1 ||
                field.IndexOf('\n') > -1 ||
                field.StartsWith(" ") ||
                field.StartsWith("\t") ||
                field.EndsWith(" ") ||
                field.EndsWith("\t");
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            for (int r = 0; r < this.dataGridView1.RowCount; r++)
            {
                dataGridView1.Rows[r].Cells[dataGridView1.ColumnCount - 1].Value = "";
            }
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }

        /// <summary>
        /// テスト
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            for (var r = 0; r < dataGridView1.Rows.Count; r++)
            {
                string str = (dataGridView1.Rows[r].Cells[1].Value ?? "").ToString();
                string ms = "";
                var item = dataGridView1.Rows[r];
                if (str.Length>0 && (item.Cells[2].Value ?? "").ToString().Length > 0)
                {
                    string[] ids = str.Trim().Split(' ');
                    foreach (string istr in ids)
                    {
                        int id = int.Parse(istr);
                        Regex re = new Regex("[０-９Ａ-Ｚａ-ｚ：－　（）[］｛｝＠／．，]+");
                        str = (item.Cells[5].Value ?? "").ToString();
                        str = re.Replace(str, (MatchEvaluator)((Match m) => { return Strings.StrConv(m.Value, VbStrConv.Narrow, 0); }));
                        str = str.Trim(new char[] { ' ' });
                        if (!tzList.Keys.Contains(id))
                        {
                            tzList[id] = new Dictionary<string, string>();
                        }
                        switch ((item.Cells[3].Value ?? "").ToString())
                        {
                            case "RegExp":
                                string pattern = (item.Cells[4].Value ?? "").ToString();
                                var mc = Regex.Matches(str, pattern);
                                foreach (Match m in mc)
                                {
                                    if (m.Groups["name1"].Success) { tzList[id]["本名"] = m.Groups["name1"].Value; }
                                    if (m.Groups["name2"].Success) { tzList[id]["通名"] = m.Groups["name2"].Value; }
                                    if (m.Groups["workname"].Success) { tzList[id]["勤務先名称"] = m.Groups["workname"].Value; }
                                    if (m.Groups["workaddr"].Success) { tzList[id]["勤務先住所"] = m.Groups["workaddr"].Value; }
                                    if (m.Groups["worktelno"].Success) { tzList[id]["電話番号"] = m.Groups["worktelno"].Value; }
                                }
                                break;
                            case "Substr":
                                var p = (item.Cells[4].Value ?? "").ToString().Split(' ');
                                if (p.Length == 1)
                                {
                                    ms = str.Substring(int.Parse(p[0]));
                                }
                                else if (p.Length == 2)
                                {
                                    ms = str.Substring(int.Parse(p[0]), int.Parse(p[1]));
                                }
                                tzList[id][item.Cells[2].Value.ToString()] = ms;
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
            foreach (var c in tzList.Keys)
            {
                var sb = new StringBuilder();
                FindDict.target = tzList[c];
                sb.Append(c.ToString("0000") + "  ");
                foreach (var key in tzList[c].Keys)
                {
                    sb.Append(key + ":" + tzList[c][key] + "; ");
                }
                listBox1.Items.Add(sb.ToString());
            }

        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {

            try
            {
                if (e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back)
                {
                    var range = dataGridView1.SelectedCells;
                    foreach (DataGridViewCell cell in range)
                    {
                        cell.Value = "";
                    }

                }
                if (e.Control && e.KeyCode == Keys.C)
                {
                    Clipboard.SetDataObject(dataGridView1.GetClipboardContent());
                    var range = dataGridView1.SelectedCells;
                    int col_count = 0;
                    int row_count = 0;
                    int col_min = 999;
                    int col_max = 0;
                    int row_min = 999;
                    int row_max = 0;
                    foreach (DataGridViewCell cell in range)
                    {
                        if (col_min > cell.ColumnIndex) col_min = cell.ColumnIndex;
                        if (col_max < cell.ColumnIndex) col_max = cell.ColumnIndex;
                        if (row_min > cell.RowIndex) row_min = cell.RowIndex;
                        if (row_max < cell.RowIndex) row_max = cell.RowIndex;
                    }
                    col_count = col_max - col_min + 1;
                    row_count = row_max - row_min + 1;

                    int[,] pos = new int[row_count, col_count];
                    for (int idx = 0; idx < range.Count; idx++)
                    {
                        pos[range[idx].RowIndex - row_min, range[idx].ColumnIndex - col_min] = idx;
                    }

                    var sb = new StringBuilder();
                    for (int r = 0; r < row_count; r++)
                    {
                        for (int c = 0; c < col_count; c++)
                        {
                            var field = (range[pos[r, c]].Value ?? "").ToString();
                            field = EncloseDoubleQuotesIfNeed(field);
                            sb.Append(field);
                            if (c < col_count - 1)
                            {
                                sb.Append(",");
                            }
                        }
                        sb.AppendLine();
                    }
                    try
                    {
                        byte[] bs = System.Text.Encoding.Default.GetBytes(sb.ToString());
                        System.IO.MemoryStream ms = new System.IO.MemoryStream(bs);
                        //CSV形式でクリップボードに貼り付ける
                        DataObject data = new DataObject(DataFormats.CommaSeparatedValue, ms);
                        //クリップボードに貼り付ける
                        Clipboard.SetDataObject(data);
                    }
                    catch { }
                }
                if (e.Control && e.KeyCode == Keys.V)
                {
                    //クリップボードのデータを取得する
                    IDataObject data = Clipboard.GetDataObject();
                    //データがある時
                    if (data != null)
                    {
                        var fmts = data.GetFormats();
                        if (fmts.Contains(DataFormats.CommaSeparatedValue))
                        {
                            //MemoryStreamとして取得する
                            byte[] bs = System.Text.Encoding.Default.GetBytes((string)data.GetData(DataFormats.CommaSeparatedValue));
                            System.IO.MemoryStream ms = new System.IO.MemoryStream(bs);
                            if (ms != null)
                            {
                                //エンコードするためのStreamReaderを作成する
                                System.IO.StreamReader sr =
                                    new System.IO.StreamReader(ms, System.Text.Encoding.Default);
                                //エンコードして、文字列に変換する
                                string csvText = sr.ReadToEnd();


                                //前後の改行を削除しておく
                                csvText = csvText.Trim(new char[] { '\r', '\n' });

                                //一行取り出すための正規表現
                                System.Text.RegularExpressions.Regex regLine =
                                    new System.Text.RegularExpressions.Regex(
                                    "^.*(?:\\n|$)",
                                    System.Text.RegularExpressions.RegexOptions.Multiline);

                                //1行のCSVから各フィールドを取得するための正規表現
                                System.Text.RegularExpressions.Regex regCsv =
                                    new System.Text.RegularExpressions.Regex(
                                    "\\s*(\"(?:[^\"]|\"\")*\"|[^,]*)\\s*,",
                                    System.Text.RegularExpressions.RegexOptions.None);

                                System.Text.RegularExpressions.Match mLine = regLine.Match(csvText);
                                int row_index = dataGridView1.SelectedCells[0].RowIndex;
                                int col_index = dataGridView1.SelectedCells[0].ColumnIndex;
                                // 行数を見て追加
                                int row_num = csvText.Split(new string[] { "\r\n" }, StringSplitOptions.None).Count();
                                if (row_index + row_num > dataGridView1.Rows.Count)
                                {
                                    for (int j = 0; j < row_num + row_index - dataGridView1.Rows.Count; j++)
                                    {
                                        dataGridView1.Rows.Add();
                                    }
                                }
                                while (mLine.Success)
                                {
                                    //一行取り出す
                                    string line = mLine.Value;
                                    //改行記号が"で囲まれているか調べる
                                    while ((CountString(line, "\"") % 2) == 1)
                                    {
                                        mLine = mLine.NextMatch();
                                        if (!mLine.Success)
                                        {
                                            return;
                                        }
                                        line += mLine.Value;
                                    }
                                    //行の最後の改行記号を削除
                                    line = line.TrimEnd(new char[] { '\r', '\n' });
                                    //最後に「,」をつける
                                    line += ",";

                                    //1つの行からフィールドを取り出す
                                    System.Text.RegularExpressions.Match m = regCsv.Match(line);

                                    int c = col_index;
                                    while (m.Success)
                                    {
                                        string field = m.Groups[1].Value;
                                        //前後の空白を削除
                                        field = field.Trim();
                                        //"で囲まれている時
                                        if (field.StartsWith("\"") && field.EndsWith("\""))
                                        {
                                            //前後の"を取る
                                            field = field.Substring(1, field.Length - 2);
                                            //「""」を「"」にする
                                            field = field.Replace("\"\"", "\"");
                                        }
                                        if (c < dataGridView1.ColumnCount)
                                        {
                                            dataGridView1.Rows[row_index].Cells[c].Value = field;
                                            c++;
                                        }
                                        m = m.NextMatch();
                                    }
                                    mLine = mLine.NextMatch();
                                    row_index++;
                                }

                            }
                        }
                    }
                }


            }
            catch { }


        }
    }
    public static class FindDict
    {
        public static Dictionary<string, string> target;
        public static bool search(Dictionary<string,string> source)
        {
            if (target == null)
            {
                return false;
            }
            else
            {
                return (target.Equals(source));
            }
        }
    }
}
